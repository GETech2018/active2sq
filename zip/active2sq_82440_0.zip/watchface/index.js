﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_calorie_target_text_font = ''
        let normal_step_current_text_font = ''
        let normal_battery_current_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_temperature_max_min_text_font = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab', 'Dom'];
        let normal_day_text_font = ''
        let normal_time_hour_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_time_minute_text_font = ''
        let normal_time_second_text_font = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg = ''
        let idle_time_hour_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_time_minute_text_font = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_1 = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['bg2_1.png', 'bg2_2.png', 'bg2_3.png', 'bg2_4.png', 'bg2_5.png', 'bg2_6.png', 'bg2_7.png'];
        let backgroundToastList = ['Rosso', 'Arancio', 'Giallo', 'Verde', 'Azzurro', 'Blu', 'Viola'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Helvetica-Bold.ttf; FontSize: 50
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 663,
              h: 68,
              text_size: 50,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Helvetica-Bold.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Helvetica-Bold.ttf; FontSize: 40
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 523,
              h: 54,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Helvetica-Bold.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Helvetica-Bold.ttf; FontSize: 42
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 550,
              h: 56,
              text_size: 42,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Helvetica-Bold.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Helvetica-Bold.ttf; FontSize: 50; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 60,
              h: 60,
              text_size: 50,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Helvetica-Bold.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Helvetica-Bold.ttf; FontSize: 120
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 1579,
              h: 160,
              text_size: 120,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Helvetica-Bold.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region SwitchBackground
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
            };
            //#endregion

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'bg2_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_target_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 253,
              y: 317,
              w: 136,
              h: 80,
              text_size: 50,
              char_space: 0,
              font: 'fonts/Helvetica-Bold.ttf',
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL_TARGET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 1,
              y: 317,
              w: 133,
              h: 80,
              text_size: 40,
              char_space: 0,
              font: 'fonts/Helvetica-Bold.ttf',
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 28,
              y: 56,
              w: 80,
              h: 80,
              text_size: 50,
              char_space: 0,
              font: 'fonts/Helvetica-Bold.ttf',
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 136,
              y: 317,
              w: 117,
              h: 80,
              text_size: 50,
              char_space: 0,
              font: 'fonts/Helvetica-Bold.ttf',
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_max_min_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 261,
              y: 71,
              w: 130,
              h: 50,
              text_size: 42,
              char_space: 0,
              font: 'fonts/Helvetica-Bold.ttf',
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 140,
              y: 10,
              w: 110,
              h: 50,
              text_size: 50,
              char_space: 0,
              font: 'fonts/Helvetica-Bold.ttf',
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: Lun,Mar,Mer,Gio,Ven,Sab,Dom,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 136,
              y: 56,
              w: 117,
              h: 80,
              text_size: 50,
              char_space: 0,
              font: 'fonts/Helvetica-Bold.ttf',
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            normal_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 21,
              y: 152,
              w: 140,
              h: 163,
              text_size: 120,
              char_space: 0,
              font: 'fonts/Helvetica-Bold.ttf',
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 184,
              y: 152,
              w: 140,
              h: 163,
              text_size: 120,
              char_space: 0,
              font: 'fonts/Helvetica-Bold.ttf',
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 328,
              y: 210,
              w: 59,
              h: 80,
              text_size: 50,
              char_space: 0,
              font: 'fonts/Helvetica-Bold.ttf',
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 3,
              y: 265,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 10,
              y: 154,
              src: 'alarm_icon.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 20,
              y: 145,
              w: 140,
              h: 163,
              text_size: 120,
              char_space: 0,
              font: 'fonts/Helvetica-Bold.ttf',
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 178,
              y: 145,
              w: 150,
              h: 163,
              text_size: 120,
              char_space: 0,
              font: 'fonts/Helvetica-Bold.ttf',
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 5,
              y: 265,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 10,
              y: 154,
              src: 'alarm_icon.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 12,
              y: 319,
              w: 112,
              h: 120,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 139,
              y: 319,
              w: 112,
              h: 120,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 12,
              y: 12,
              w: 112,
              h: 120,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 267,
              y: 12,
              w: 112,
              h: 120,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 20,
              y: 168,
              w: 300,
              h: 120,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 267,
              y: 319,
              w: 112,
              h: 120,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 139,
              y: 12,
              w: 112,
              h: 120,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 330,
              // y: 141,
              // w: 55,
              // h: 100,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: 'rainbow_circle.png',
              // normal_src: 'rainbow_circle.png',
              // bg_list: bg2_1|bg2_2|bg2_3|bg2_4|bg2_5|bg2_6|bg2_7,
              // toast_list: Rosso|Arancio|Giallo|Verde|Azzurro|Blu|Viola,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: False,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 330,
              y: 141,
              w: 55,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'rainbow_circle.png',
              normal_src: 'rainbow_circle.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('hour font');
              if (updateHour) {
                let normal_hourStr = format_hour.toString();
                normal_hourStr = normal_hourStr.padStart(2, '0');
                normal_time_hour_text_font.setProperty(hmUI.prop.TEXT, normal_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let normal_minuteStr = minute.toString();
                normal_minuteStr = normal_minuteStr.padStart(2, '0');
                normal_time_minute_text_font.setProperty(hmUI.prop.TEXT, normal_minuteStr );
              };

              console.log('second font');
                let normal_secondStr = second.toString();
                normal_secondStr = normal_secondStr.padStart(2, '0');
                normal_time_second_text_font.setProperty(hmUI.prop.TEXT, normal_secondStr );
              console.log('hour font');
              if (updateHour) {
                let idle_hourStr = format_hour.toString();
                idle_time_hour_text_font.setProperty(hmUI.prop.TEXT, idle_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let idle_minuteStr = minute.toString();
                idle_minuteStr = idle_minuteStr.padStart(2, '0');
                idle_time_minute_text_font.setProperty(hmUI.prop.TEXT, idle_minuteStr );
              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}