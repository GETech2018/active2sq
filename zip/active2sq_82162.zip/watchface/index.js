﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

// Activity select

        let backgroundnumber = 1
        let totalpictures = 3
        let cc = 0

        function click_switch_info() {
            if(backgroundnumber>=totalpictures) {
            backgroundnumber=1;
                UpdateBackgroundOne();
                }
            else {
                backgroundnumber=backgroundnumber+1;
                if(backgroundnumber==2) {
                  UpdateBackgroundTwo();
                }
                if(backgroundnumber==3) {
                  UpdateBackgroundThree();
                }

    

            }
          if(backgroundnumber==1) hmUI.showToast({text: 'Steps'});
          if(backgroundnumber==2) hmUI.showToast({text: 'Distance'});
          if(backgroundnumber==3) hmUI.showToast({text: 'Calories'});

        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //steps
        function UpdateBackgroundOne(){

        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);

        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
 
        normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, true);


            normal_step_TextCircle_ASCIIARRAY[0] = '0034.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = '0035.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = '0036.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = '0037.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = '0038.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = '0039.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = '0040.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = '0041.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = '0042.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = '0043.png';  // set of images with numbers


            normal_calorie_TextCircle_ASCIIARRAY[0] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[1] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[2] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[3] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[4] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[5] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[6] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[7] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[8] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[9] = '0_Empty.png';  // set of images with numbers


            normal_distance_TextCircle_ASCIIARRAY[0] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[1] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[2] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[3] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[4] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[5] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[6] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[7] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[8] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[9] = '0_Empty.png';  // set of images with numbers


            normal_distance_TextCircle_unit.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 243,
              center_y: 173,
              pos_x: 243 - normal_distance_TextCircle_unit_width / 2,
              pos_y: 173 - 206,
              src: '0_Empty.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);

            const mileageUnit = hmSetting.getMileageUnit();
            if (mileageUnit == 1) {
              normal_distance_TextCircle_unit.setProperty(hmUI.prop.SRC, '0_Empty.png');
            };

        normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);

        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //Distance
        function UpdateBackgroundTwo(){

        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);

        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, true);


            normal_step_TextCircle_ASCIIARRAY[0] = '0_Empty.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = '0_Empty.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = '0_Empty.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = '0_Empty.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = '0_Empty.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = '0_Empty.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = '0_Empty.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = '0_Empty.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = '0_Empty.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = '0_Empty.png';  // set of images with numbers


            normal_calorie_TextCircle_ASCIIARRAY[0] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[1] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[2] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[3] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[4] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[5] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[6] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[7] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[8] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[9] = '0_Empty.png';  // set of images with numbers


            normal_distance_TextCircle_ASCIIARRAY[0] = '0034.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[1] = '0035.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[2] = '0036.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[3] = '0037.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[4] = '0038.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[5] = '0039.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[6] = '0040.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[7] = '0041.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[8] = '0042.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[9] = '0043.png';  // set of images with numbers

            normal_distance_TextCircle_unit.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 243,
              center_y: 173,
              pos_x: 243 - normal_distance_TextCircle_unit_width / 2,
              pos_y: 173 - 206,
              src: '0119.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);

            const mileageUnit = hmSetting.getMileageUnit();
            if (mileageUnit == 1) {
              normal_distance_TextCircle_unit.setProperty(hmUI.prop.SRC, '0120.png');
            };

        normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);

        }
//////////////////////////////////////////////////////////////////////////////////////////////////

        //Calories
        function UpdateBackgroundThree(){

        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
 
        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);


        normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, false);


           normal_step_TextCircle_ASCIIARRAY[0] = '0_Empty.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = '0_Empty.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = '0_Empty.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = '0_Empty.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = '0_Empty.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = '0_Empty.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = '0_Empty.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = '0_Empty.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = '0_Empty.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = '0_Empty.png';  // set of images with numbers


            normal_calorie_TextCircle_ASCIIARRAY[0] = '0034.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[1] = '0035.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[2] = '0036.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[3] = '0037.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[4] = '0038.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[5] = '0039.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[6] = '0040.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[7] = '0041.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[8] = '0042.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[9] = '0043.png';  // set of images with numbers


            normal_distance_TextCircle_ASCIIARRAY[0] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[1] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[2] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[3] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[4] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[5] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[6] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[7] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[8] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[9] = '0_Empty.png';  // set of images with numbers

            normal_distance_TextCircle_unit.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 243,
              center_y: 173,
              pos_x: 243 - normal_distance_TextCircle_unit_width / 2,
              pos_y: 173 - 206,
              src: '0_Empty.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);

            const mileageUnit = hmSetting.getMileageUnit();
            if (mileageUnit == 1) {
              normal_distance_TextCircle_unit.setProperty(hmUI.prop.SRC, '0_Empty.png');
            };

        normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);


        }
//////////////////////////////////////////////////////////////////////////////////////////////////
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_alarm_clock_text_text_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_TextCircle = new Array(5);
        let normal_distance_TextCircle_ASCIIARRAY = new Array(10);
        let normal_distance_TextCircle_img_width = 26;
        let normal_distance_TextCircle_img_height = 47;
        let normal_distance_TextCircle_unit = null;
        let normal_distance_TextCircle_unit_width = 38;
        let normal_distance_TextCircle_dot_width = 6;
        let normal_distance_TextCircle_error_img_width = 13;
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_TextCircle = new Array(4);
        let normal_calorie_TextCircle_ASCIIARRAY = new Array(10);
        let normal_calorie_TextCircle_img_width = 26;
        let normal_calorie_TextCircle_img_height = 47;
        let normal_calorie_TextCircle_error_img_width = 13;
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_step_circle_scale = ''
        let normal_step_icon_img = ''
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 26;
        let normal_step_TextCircle_img_height = 47;
        let normal_step_TextCircle_error_img_width = 13;
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_hour_TextCircle = new Array(2);
        let normal_hour_TextCircle_ASCIIARRAY = new Array(10);
        let normal_hour_TextCircle_img_width = 32;
        let normal_hour_TextCircle_img_height = 43;
        let normal_hour_TextCircle_unit = null;
        let normal_hour_TextCircle_unit_width = 12;
        let normal_timerTextUpdate = undefined;
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_minute_TextCircle = new Array(2);
        let normal_minute_TextCircle_ASCIIARRAY = new Array(10);
        let normal_minute_TextCircle_img_width = 32;
        let normal_minute_TextCircle_img_height = 43;
        let normal_digital_clock_img_time_AmPm = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_second_cover_pointer_img = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_img_time_AmPm = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['0001.png', 'bg2.png', 'bg3.png', 'bg4.png', 'bg5.png', 'bg6.png'];
        let backgroundToastList = ['G R E E N', 'B L U E', 'O R A N G E', 'P I N K', 'B R O W N', 'G R E Y'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;
        
        let degreeSum = 0;
        let crownSensitivity = 70;  // crown sensitivity level
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //#region onDigitalCrown
            console.log('onDigitalCrown()');
            function onDigitalCrown() {
              setTimeout(() => {
                hmApp.registerSpinEvent(function (key, degree) {
                  if (key === hmApp.key.HOME) {
                    degreeSum += degree;
                    if (Math.abs(degreeSum) > crownSensitivity){
                      let step = degreeSum < 0 ? -1 : 1;
                      degreeSum = 0;
                      
                      console.log('SwitchBackground use crown');
                      backgroundIndex += step;
                      backgroundIndex = backgroundIndex < 0 ? backgroundList.length + backgroundIndex : backgroundIndex % backgroundList.length;
                      hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                      let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
                      if (toastText.length > 0) hmUI.showToast({text: toastText});
                      normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
                      vibro(28);
                    }
                  } // key
                }) // crown
              }, 250);
            }
            //#endregion

            //#region SwitchBackground
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              vibro(28);
            };
            //#endregion

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 225,
              y: 235,
              font_array: ["0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png"],
              padding: true,
              h_space: 3,
              invalid_image: '0021.png',
              dot_image: '0019.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 332,
              y: 156,
              src: '0083.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 130,
              y: 156,
              src: '0084.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 144,
              y: 0,
              src: '0082.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 186,
              y: 234,
              src: '0085.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 81,
              // center_y: 313,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 83,
              // line_width: 15,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 175,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 81,
              center_y: 313,
              start_angle: 360,
              end_angle: 0,
              radius: 76,
              line_width: 15,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_circle_scale.setAlpha(175);
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 33,
              y: 297,
              font_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              padding: false,
              h_space: 4,
              unit_sc: '0044.png',
              unit_tc: '0044.png',
              unit_en: '0044.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 192,
              // center_y: 377,
              // start_angle: 360,
              // end_angle: 0,
              // radius: 47,
              // line_width: 9,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 175,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 192,
              center_y: 377,
              start_angle: 0,
              end_angle: 360,
              radius: 43,
              line_width: 9,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_circle_scale.setAlpha(175);
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 165,
              y: 371,
              font_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
              padding: false,
              h_space: 4,
              invalid_image: '0052.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_distance_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 243,
              // circle_center_Y: 173,
              // font_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              // radius: 183,
              // angle: -63,
              // char_space_angle: 1,
              // unit: '0119.png',
              // imperial_unit: '0120.png',
              // dot_image: '0121.png',
              // error_image: '0020.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextCircle_ASCIIARRAY[0] = '0034.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[1] = '0035.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[2] = '0036.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[3] = '0037.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[4] = '0038.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[5] = '0039.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[6] = '0040.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[7] = '0041.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[8] = '0042.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[9] = '0043.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 5; i++) {
              normal_distance_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 243,
                center_y: 173,
                pos_x: 243 - normal_distance_TextCircle_img_width / 2,
                pos_y: 173 - 206,
                src: '0034.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_distance_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 243,
              center_y: 173,
              pos_x: 243 - normal_distance_TextCircle_unit_width / 2,
              pos_y: 173 - 206,
              src: '0119.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);

            const mileageUnit = hmSetting.getMileageUnit();
            if (mileageUnit == 1) {
              normal_distance_TextCircle_unit.setProperty(hmUI.prop.SRC, '0120.png');
            };
            //#endregion
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 395,
              y: 0,
              font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 36,
              y: 169,
              src: 'Distance.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 243,
              // center_y: 173,
              // start_angle: -103,
              // end_angle: -43,
              // radius: 235,
              // line_width: 15,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 175,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 243,
              center_y: 173,
              start_angle: -43,
              end_angle: -103,
              radius: 228,
              line_width: 15,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_circle_scale.setAlpha(175);
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 23,
              y: 7,
              src: 'BG_element.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_calorie_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 243,
              // circle_center_Y: 173,
              // font_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              // radius: 183,
              // angle: -68,
              // char_space_angle: 2,
              // error_image: '0020.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextCircle_ASCIIARRAY[0] = '0034.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[1] = '0035.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[2] = '0036.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[3] = '0037.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[4] = '0038.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[5] = '0039.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[6] = '0040.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[7] = '0041.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[8] = '0042.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[9] = '0043.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 243,
                center_y: 173,
                pos_x: 243 - normal_calorie_TextCircle_img_width / 2,
                pos_y: 173 - 206,
                src: '0034.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 395,
              y: 0,
              font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 36,
              y: 169,
              src: 'kCal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 243,
              // center_y: 173,
              // start_angle: -103,
              // end_angle: -43,
              // radius: 235,
              // line_width: 15,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 175,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 243,
              center_y: 173,
              start_angle: -43,
              end_angle: -103,
              radius: 228,
              line_width: 15,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_circle_scale.setAlpha(175);
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 23,
              y: 7,
              src: 'BG_element.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 243,
              // circle_center_Y: 173,
              // font_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              // radius: 183,
              // angle: -65,
              // char_space_angle: 2,
              // error_image: '0020.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = '0034.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = '0035.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = '0036.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = '0037.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = '0038.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = '0039.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = '0040.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = '0041.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = '0042.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = '0043.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 243,
                center_y: 173,
                pos_x: 243 - normal_step_TextCircle_img_width / 2,
                pos_y: 173 - 206,
                src: '0034.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 395,
              y: 0,
              font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 36,
              y: 169,
              src: 'Steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 57,
              y: 403,
              week_en: ["0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
              week_tc: ["0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
              week_sc: ["0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 121,
              day_startY: 408,
              day_sc_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
              day_tc_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
              day_en_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 144,
              y: 0,
              w: 200,
              h: 30,
              text_size: 25,
              char_space: 2,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 233,
              y: 298,
              image_array: ["0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 234,
              y: 397,
              font_array: ["0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png"],
              padding: false,
              h_space: 4,
              unit_sc: '0018.png',
              unit_tc: '0018.png',
              unit_en: '0018.png',
              negative_image: '0017.png',
              invalid_image: '0017.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_hour_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 242,
              // circle_center_Y: 172,
              // font_array: ["0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png"],
              // radius: 78,
              // angle: -21,
              // char_space_angle: 2,
              // unit: '0118.png',
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextCircle_ASCIIARRAY[0] = '0108.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[1] = '0109.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[2] = '0110.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[3] = '0111.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[4] = '0112.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[5] = '0113.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[6] = '0114.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[7] = '0115.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[8] = '0116.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[9] = '0117.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 2; i++) {
              normal_hour_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 242,
                center_y: 172,
                pos_x: 242 - normal_hour_TextCircle_img_width / 2,
                pos_y: 172 - 121,
                src: '0108.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_hour_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 242,
              center_y: 172,
              pos_x: 242 - normal_hour_TextCircle_unit_width / 2,
              pos_y: 172 - 121,
              src: '0118.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 391,
              hour_startY: 389,
              hour_array: ["0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 341,
              y: 37,
              src: '0107.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_minute_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 242,
              // circle_center_Y: 172,
              // font_array: ["0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png"],
              // radius: 78,
              // angle: 18,
              // char_space_angle: 2,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextCircle_ASCIIARRAY[0] = '0108.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[1] = '0109.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[2] = '0110.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[3] = '0111.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[4] = '0112.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[5] = '0113.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[6] = '0114.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[7] = '0115.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[8] = '0116.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[9] = '0117.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 2; i++) {
              normal_minute_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 242,
                center_y: 172,
                pos_x: 242 - normal_minute_TextCircle_img_width / 2,
                pos_y: 172 - 121,
                src: '0108.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 341,
              am_y: 37,
              am_sc_path: '0022.png',
              am_en_path: '0022.png',
              pm_x: 341,
              pm_y: 37,
              pm_sc_path: '0023.png',
              pm_en_path: '0023.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0003.png',
              // center_x: 243,
              // center_y: 173,
              // x: 22,
              // y: 140,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 243 - 22,
              pos_y: 173 - 140,
              center_x: 243,
              center_y: 173,
              src: '0003.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0004.png',
              // center_x: 243,
              // center_y: 173,
              // x: 22,
              // y: 140,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 243 - 22,
              pos_y: 173 - 140,
              center_x: 243,
              center_y: 173,
              src: '0004.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0005.png',
              // center_x: 243,
              // center_y: 173,
              // x: 22,
              // y: 140,
              // start_angle: 0,
              // end_angle: 360,
              // cover_path: '0006.png',
              // cover_x: 228,
              // cover_y: 156,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 243 - 22,
              pos_y: 173 - 140,
              center_x: 243,
              center_y: 173,
              src: '0005.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_pro_second_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 228,
              y: 156,
              src: '0006.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 27,
              hour_startY: 184,
              hour_array: ["0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png"],
              hour_zero: 1,
              hour_space: 15,
              hour_angle: 0,
              hour_unit_sc: '0106.png',
              hour_unit_tc: '0106.png',
              hour_unit_en: '0106.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 223,
              minute_startY: 184,
              minute_array: ["0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png"],
              minute_zero: 1,
              minute_space: 15,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 181,
              am_y: 287,
              am_sc_path: '0022.png',
              am_en_path: '0022.png',
              pm_x: 181,
              pm_y: 287,
              pm_sc_path: '0023.png',
              pm_en_path: '0023.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: BT Off,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: BT On,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "BT Off"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "BT On"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 256,
              y: 54,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0021.png',
              normal_src: '0021.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'CompassScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 161,
              y: 54,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0021.png',
              normal_src: '0021.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WorldClockScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'MusicCommonScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 248,
              y: 324,
              w: 100,
              h: 120,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0021.png',
              normal_src: '0021.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 9,
              w: 100,
              h: 166,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0021.png',
              normal_src: '0021.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 32,
              y: 261,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0021.png',
              normal_src: '0021.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'FlashLightScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 163,
              y: 346,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0021.png',
              normal_src: '0021.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'oneKeyAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 389,
              w: 150,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0021.png',
              normal_src: '0021.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'MorningGreetingCoverScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 312,
              y: 143,
              w: 88,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0021.png',
              normal_src: '0021.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'OnlineVADScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 181,
              w: 100,
              h: 55,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0021.png',
              normal_src: '0021.png',
              click_func: (button_widget) => {
                // switch info
                click_switch_info()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 144,
              // y: 0,
              // w: 200,
              // h: 40,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: '0021.png',
              // normal_src: '0021.png',
              // bg_list: 0001|bg2|bg3|bg4|bg5|bg6,
              // toast_list: G R E E N|B L U E|O R A N G E|P I N K|B R O W N|G R E Y,
              // use_crown: True,
              // use_in_AOD: False,
              // vibro: True,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 144,
              y: 0,
              w: 200,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0021.png',
              normal_src: '0021.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

if ( cc == 0 ){
UpdateBackgroundOne()
cc=1
}
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateMinute) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*minute/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            //#endregion
            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text circle DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_circle_string = (distanceCurrent / 1000).toFixed(2);
              if (mileageUnit == 1) normal_distance_circle_string = (0.621371 * distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = -63;
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_circle_string.length > 0 && normal_distance_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_distance_TextCircle_img_angle = 0;
                  let normal_distance_TextCircle_dot_img_angle = 0;
                  let normal_distance_TextCircle_unit_angle = 0;
                  normal_distance_TextCircle_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_img_width/2, 183));
                  normal_distance_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_dot_width/2, 183));
                  normal_distance_TextCircle_unit_angle = toDegree(Math.atan2(normal_distance_TextCircle_unit_width/2, 183));
                  // alignment = CENTER_H
                  let normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_img_angle * (normal_distance_circle_string.length - 1);
                  normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_angleOffset - normal_distance_TextCircle_img_angle + normal_distance_TextCircle_dot_img_angle;
                  normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_angleOffset + 1 * (normal_distance_circle_string.length - 1) / 2;
                  normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_angleOffset + (normal_distance_TextCircle_img_angle + normal_distance_TextCircle_unit_angle + 1) / 2;
                  char_Angle -= normal_distance_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_distance_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_distance_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 243 - normal_distance_TextCircle_img_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, normal_distance_TextCircle_ASCIIARRAY[charCode]);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_distance_TextCircle_img_angle + 1;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_distance_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 243 - normal_distance_TextCircle_dot_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, '0121.png');
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_distance_TextCircle_dot_img_angle + 1;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle += normal_distance_TextCircle_unit_angle;
                  normal_distance_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.POS_X, 243 - normal_distance_TextCircle_error_img_width / 2);
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.SRC, '0020.png');
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_circle_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -68;
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_circle_string.length > 0 && normal_calorie_circle_string.length <= 4) {  // display data if it was possible to get it
                  let normal_calorie_TextCircle_img_angle = 0;
                  let normal_calorie_TextCircle_dot_img_angle = 0;
                  normal_calorie_TextCircle_img_angle = toDegree(Math.atan2(normal_calorie_TextCircle_img_width/2, 183));
                  // alignment = CENTER_H
                  let normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_img_angle * (normal_calorie_circle_string.length - 1);
                  normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_angleOffset + 2 * (normal_calorie_circle_string.length - 1) / 2;
                  char_Angle -= normal_calorie_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_calorie_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_calorie_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 243 - normal_calorie_TextCircle_img_width / 2);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, normal_calorie_TextCircle_ASCIIARRAY[charCode]);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_calorie_TextCircle_img_angle + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_calorie_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_calorie_TextCircle[0].setProperty(hmUI.prop.POS_X, 243 - normal_calorie_TextCircle_error_img_width / 2);
                  normal_calorie_TextCircle[0].setProperty(hmUI.prop.SRC, '0020.png');
                  normal_calorie_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle step_STEP');
              let valueStep = step.current;
              let normal_step_circle_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -65;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, 183));
                  // alignment = CENTER_H
                  let normal_step_TextCircle_angleOffset = normal_step_TextCircle_img_angle * (normal_step_circle_string.length - 1);
                  normal_step_TextCircle_angleOffset = normal_step_TextCircle_angleOffset + 2 * (normal_step_circle_string.length - 1) / 2;
                  char_Angle -= normal_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 243 - normal_step_TextCircle_img_width / 2);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_step_TextCircle_img_angle + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_step_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_step_TextCircle[0].setProperty(hmUI.prop.POS_X, 243 - normal_step_TextCircle_error_img_width / 2);
                  normal_step_TextCircle[0].setProperty(hmUI.prop.SRC, '0020.png');
                  normal_step_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle hour_TIME');
              let valueHour = timeSensor.format_hour;
              let normal_hour_circle_string = parseInt(valueHour).toString();
              normal_hour_circle_string = normal_hour_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = -21;
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_circle_string.length > 0 && normal_hour_circle_string.length <= 2) {  // display data if it was possible to get it
                  let normal_hour_TextCircle_img_angle = 0;
                  let normal_hour_TextCircle_dot_img_angle = 0;
                  let normal_hour_TextCircle_unit_angle = 0;
                  normal_hour_TextCircle_img_angle = toDegree(Math.atan2(normal_hour_TextCircle_img_width/2, 78));
                  normal_hour_TextCircle_unit_angle = toDegree(Math.atan2(normal_hour_TextCircle_unit_width/2, 78));
                  // alignment = CENTER_H
                  let normal_hour_TextCircle_angleOffset = normal_hour_TextCircle_img_angle * (normal_hour_circle_string.length - 1);
                  normal_hour_TextCircle_angleOffset = normal_hour_TextCircle_angleOffset + 2 * (normal_hour_circle_string.length - 1) / 2;
                  normal_hour_TextCircle_angleOffset = normal_hour_TextCircle_angleOffset + (normal_hour_TextCircle_img_angle + normal_hour_TextCircle_unit_angle + 2) / 2;
                  char_Angle -= normal_hour_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_hour_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_hour_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.POS_X, 242 - normal_hour_TextCircle_img_width / 2);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.SRC, normal_hour_TextCircle_ASCIIARRAY[charCode]);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_hour_TextCircle_img_angle + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += normal_hour_TextCircle_unit_angle;
                  normal_hour_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle minute_TIME');
              let valueMinute = timeSensor.minute;
              let normal_minute_circle_string = parseInt(valueMinute).toString();
              normal_minute_circle_string = normal_minute_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 18;
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_circle_string.length > 0 && normal_minute_circle_string.length <= 2) {  // display data if it was possible to get it
                  let normal_minute_TextCircle_img_angle = 0;
                  let normal_minute_TextCircle_dot_img_angle = 0;
                  normal_minute_TextCircle_img_angle = toDegree(Math.atan2(normal_minute_TextCircle_img_width/2, 78));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_minute_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_minute_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.POS_X, 242 - normal_minute_TextCircle_img_width / 2);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.SRC, normal_minute_TextCircle_ASCIIARRAY[charCode]);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_minute_TextCircle_img_angle + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 81,
                      center_y: 313,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 76,
                      line_width: 15,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 184;
                let progressHeartRate = (valueHeartRate - 30)/(targetHeartRate - 30);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = 1 - progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 192,
                      center_y: 377,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 43,
                      line_width: 9,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = 1 - progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 243,
                      center_y: 173,
                      start_angle: -43,
                      end_angle: -103,
                      radius: 228,
                      line_width: 15,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 243,
                      center_y: 173,
                      start_angle: -43,
                      end_angle: -103,
                      radius: 228,
                      line_width: 15,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
                onDigitalCrown();
              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                stopVibro();

                hmApp.unregisterSpinEvent();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}