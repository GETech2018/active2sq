﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_text_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_altitude_target_text_img = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_current_separator_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_sun_current_text_img = ''
        let normal_sun_current_separator_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_body_temp_current_text_font = ''
        let normal_body_temp_text_text_img = ''
        let normal_body_temp_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_floor_text_text_img = ''
        let normal_floor_text_separator_img = ''
        let idle_background_bg = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'bg_soul_background_poster.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 72,
              y: 1,
              image_array: ["bah_00.png","bah_01.png","bah_02.png","bah_03.png","bah_04.png","bah_05.png","bah_06.png","bah_07.png","bah_08.png","bah_09.png","bah_10.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 27,
              y: 247,
              font_array: ["nb3_0.png","nb3_1.png","nb3_2.png","nb3_3.png","nb3_4.png","nb3_5.png","nb3_6.png","nb3_7.png","nb3_8.png","nb3_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 1,
              y: 237,
              src: 'humidity.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 281,
              y: 358,
              src: 'BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 126,
              y: 325,
              src: 'al2.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 41,
              y: 420,
              week_en: ["weekday_1.png","weekday_2.png","weekday_3.png","weekday_4.png","weekday_5.png","weekday_6.png","weekday_7.png"],
              week_tc: ["weekday_1.png","weekday_2.png","weekday_3.png","weekday_4.png","weekday_5.png","weekday_6.png","weekday_7.png"],
              week_sc: ["weekday_1.png","weekday_2.png","weekday_3.png","weekday_4.png","weekday_5.png","weekday_6.png","weekday_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 20,
              month_startY: 391,
              month_sc_array: ["nb4_0.png","nb4_1.png","nb4_2.png","nb4_3.png","nb4_4.png","nb4_5.png","nb4_6.png","nb4_7.png","nb4_8.png","nb4_9.png"],
              month_tc_array: ["nb4_0.png","nb4_1.png","nb4_2.png","nb4_3.png","nb4_4.png","nb4_5.png","nb4_6.png","nb4_7.png","nb4_8.png","nb4_9.png"],
              month_en_array: ["nb4_0.png","nb4_1.png","nb4_2.png","nb4_3.png","nb4_4.png","nb4_5.png","nb4_6.png","nb4_7.png","nb4_8.png","nb4_9.png"],
              month_zero: 0,
              month_space: 0,
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 66,
              y: 390,
              src: 'slesh.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 81,
              day_startY: 391,
              day_sc_array: ["nb4_0.png","nb4_1.png","nb4_2.png","nb4_3.png","nb4_4.png","nb4_5.png","nb4_6.png","nb4_7.png","nb4_8.png","nb4_9.png"],
              day_tc_array: ["nb4_0.png","nb4_1.png","nb4_2.png","nb4_3.png","nb4_4.png","nb4_5.png","nb4_6.png","nb4_7.png","nb4_8.png","nb4_9.png"],
              day_en_array: ["nb4_0.png","nb4_1.png","nb4_2.png","nb4_3.png","nb4_4.png","nb4_5.png","nb4_6.png","nb4_7.png","nb4_8.png","nb4_9.png"],
              day_zero: 1,
              day_space: -2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 185,
              y: 41,
              font_array: ["nb1_0.png","nb1_1.png","nb1_2.png","nb1_3.png","nb1_4.png","nb1_5.png","nb1_6.png","nb1_7.png","nb1_8.png","nb1_9.png"],
              padding: false,
              h_space: -9,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 130,
              y: 84,
              image_array: ["steps_0.png","steps_1.png","steps_2.png","steps_3.png","steps_4.png","steps_5.png","steps_6.png","steps_7.png","steps_8.png"],
              image_length: 9,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: -2,
              y: 270,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 254,
              y: 425,
              font_array: ["nb4_0.png","nb4_1.png","nb4_2.png","nb4_3.png","nb4_4.png","nb4_5.png","nb4_6.png","nb4_7.png","nb4_8.png","nb4_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 125,
              w: 335,
              h: 35,
              text_size: 24,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 45,
              y: 220,
              font_array: ["nb2_0.png","nb2_1.png","nb2_2.png","nb2_3.png","nb2_4.png","nb2_5.png","nb2_6.png","nb2_7.png","nb2_8.png","nb2_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'nb2_d.png',
              unit_tc: 'nb2_d.png',
              unit_en: 'nb2_d.png',
              negative_image: 'nb2_m.png',
              invalid_image: 'error_w_b.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 134,
              y: 159,
              src: 'thermometer.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 78,
              y: 162,
              font_array: ["nb5_0.png","nb5_1.png","nb5_2.png","nb5_3.png","nb5_4.png","nb5_5.png","nb5_6.png","nb5_7.png","nb5_8.png","nb5_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'nb5_d.png',
              unit_tc: 'nb5_d.png',
              unit_en: 'nb5_d.png',
              negative_image: 'nb5_m.png',
              invalid_image: 'error_w_s.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 78,
              y: 184,
              font_array: ["nb5_0.png","nb5_1.png","nb5_2.png","nb5_3.png","nb5_4.png","nb5_5.png","nb5_6.png","nb5_7.png","nb5_8.png","nb5_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'nb5_d.png',
              unit_tc: 'nb5_d.png',
              unit_en: 'nb5_d.png',
              negative_image: 'nb5_m.png',
              invalid_image: 'error_w_s.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 166,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_0n.png","w_14n.png","w_1n.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 141,
              y: 428,
              font_array: ["nb5_0.png","nb5_1.png","nb5_2.png","nb5_3.png","nb5_4.png","nb5_5.png","nb5_6.png","nb5_7.png","nb5_8.png","nb5_9.png"],
              padding: false,
              h_space: -1,
              dot_image: 'sep.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 122,
              y: 424,
              src: 'icon_sa.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -5,
              hour_startY: 305,
              hour_array: ["nb7_0.png","nb7_1.png","nb7_2.png","nb7_3.png","nb7_4.png","nb7_5.png","nb7_6.png","nb7_7.png","nb7_8.png","nb7_9.png"],
              hour_zero: 0,
              hour_space: -8,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 113,
              minute_startY: 305,
              minute_array: ["nb7_0.png","nb7_1.png","nb7_2.png","nb7_3.png","nb7_4.png","nb7_5.png","nb7_6.png","nb7_7.png","nb7_8.png","nb7_9.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 170,
              second_startY: 392,
              second_array: ["nb9_0.png","nb9_1.png","nb9_2.png","nb9_3.png","nb9_4.png","nb9_5.png","nb9_6.png","nb9_7.png","nb9_8.png","nb9_9.png"],
              second_zero: 1,
              second_space: -1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 96,
              am_y: 326,
              am_sc_path: 'sepAM.png',
              am_en_path: 'sepAM.png',
              pm_x: 96,
              pm_y: 326,
              pm_sc_path: 'sepPM.png',
              pm_en_path: 'sepPM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 105,
              y: 14,
              font_array: ["nb4_0.png","nb4_1.png","nb4_2.png","nb4_3.png","nb4_4.png","nb4_5.png","nb4_6.png","nb4_7.png","nb4_8.png","nb4_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 138,
              y: 22,
              src: 'O2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_body_temp_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 0,
              y: 0,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BODY_TEMP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_body_temp_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: -65,
              y: 85,
              w: 132,
              h: 23,
              font_array: ["nb4_0.png","nb4_1.png","nb4_2.png","nb4_3.png","nb4_4.png","nb4_5.png","nb4_6.png","nb4_7.png","nb4_8.png","nb4_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BODY_TEMP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_body_temp_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 2,
              y: 86,
              src: 'handhelpTermo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 5,
              y: 16,
              font_array: ["nb6_0.png","nb6_1.png","nb6_2.png","nb6_3.png","nb6_4.png","nb6_5.png","nb6_6.png","nb6_7.png","nb6_8.png","nb6_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '0_Empty.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_floor_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 309,
              y: 10,
              font_array: ["nb4_0.png","nb4_1.png","nb4_2.png","nb4_3.png","nb4_4.png","nb4_5.png","nb4_6.png","nb4_7.png","nb4_8.png","nb4_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.FLOOR,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_floor_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 277,
              y: 10,
              src: 'stairs.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 7,
              y: 166,
              src: 'bt2.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 290,
              y: 162,
              src: 'al.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 168,
              y: 33,
              week_en: ["weekday_1.png","weekday_2.png","weekday_3.png","weekday_4.png","weekday_5.png","weekday_6.png","weekday_7.png"],
              week_tc: ["weekday_1.png","weekday_2.png","weekday_3.png","weekday_4.png","weekday_5.png","weekday_6.png","weekday_7.png"],
              week_sc: ["weekday_1.png","weekday_2.png","weekday_3.png","weekday_4.png","weekday_5.png","weekday_6.png","weekday_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 126,
              day_startY: 33,
              day_sc_array: ["nb4_0.png","nb4_1.png","nb4_2.png","nb4_3.png","nb4_4.png","nb4_5.png","nb4_6.png","nb4_7.png","nb4_8.png","nb4_9.png"],
              day_tc_array: ["nb4_0.png","nb4_1.png","nb4_2.png","nb4_3.png","nb4_4.png","nb4_5.png","nb4_6.png","nb4_7.png","nb4_8.png","nb4_9.png"],
              day_en_array: ["nb4_0.png","nb4_1.png","nb4_2.png","nb4_3.png","nb4_4.png","nb4_5.png","nb4_6.png","nb4_7.png","nb4_8.png","nb4_9.png"],
              day_zero: 1,
              day_space: -2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 171,
              y: 19,
              src: 'shadow.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 50,
              hour_startY: 163,
              hour_array: ["nb7_0.png","nb7_1.png","nb7_2.png","nb7_3.png","nb7_4.png","nb7_5.png","nb7_6.png","nb7_7.png","nb7_8.png","nb7_9.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 180,
              minute_startY: 163,
              minute_array: ["nb7_0.png","nb7_1.png","nb7_2.png","nb7_3.png","nb7_4.png","nb7_5.png","nb7_6.png","nb7_7.png","nb7_8.png","nb7_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}