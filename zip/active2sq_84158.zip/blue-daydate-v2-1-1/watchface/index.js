/*
 * Blue Day-Date Style V2.1.1 — Amazfit Active 2 Square
 * Screen: 390x450. Based on the original working V1 project.
 */
try {
  (() => {
    const app = __$$hmAppManager$$__.currentApp;
    const module = app.current;
    const logger = DeviceRuntimeCore.HmLogger.getLogger('BlueDayDateV211');

    module.module = DeviceRuntimeCore.WatchFace({
      build() {
        this.init_view();
      },

      init_view() {
        const NORMAL = hmUI.show_level.ONLY_NORMAL;
        const AOD = hmUI.show_level.ONLY_AOD;
        const EDIT = hmUI.show_level.ONLY_EDIT;

        const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
        const batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
        const stepSensor = hmSensor.createSensor(hmSensor.id.STEP);
        const weekdays = ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY'];

        const getWeekday = () => {
          const week = Number(timeSensor.week);
          if (!Number.isFinite(week) || week < 1 || week > 7) return 'MONDAY';
          return weekdays[week - 1];
        };
        const getBattery = () => {
          const value = Number(batterySensor.current);
          return 'POWER: ' + (Number.isFinite(value) ? Math.max(0, Math.min(100, value)) : '--') + '%';
        };
        const getSteps = () => {
          const value = Number(stepSensor.current);
          return 'STEPS: ' + (Number.isFinite(value) ? Math.max(0, value) : '--');
        };

        const makeText = (params) => hmUI.createWidget(hmUI.widget.TEXT, Object.assign({
          color: 0xFFE4E7EB,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          show_level: NORMAL
        }, params));

        // Main face background (the old static branding has been removed).
        hmUI.createWidget(hmUI.widget.IMG, {
          x: 0, y: 0, w: 390, h: 450,
          src: 'background.png',
          show_level: NORMAL | EDIT
        });

        // Day of week: straight and centered in the original curved plaque.
        const weekdayText = makeText({
          x: 126, y: 43, w: 138, h: 29,
          text: getWeekday(),
          text_size: 15,
          char_space: 1,
          color: 0xFF11151B
        });

        // Brand stack below the crown.
        makeText({
          x: 105, y: 119, w: 180, h: 34,
          text: 'DMZ', text_size: 28, char_space: 2,
          color: 0xFFE7E9ED
        });
        makeText({
          x: 115, y: 148, w: 160, h: 20,
          text: 'DAY-DATE', text_size: 14, char_space: 2,
          color: 0xFFD8DCE2
        });

        // Live battery percentage.
        const batteryText = makeText({
          x: 119, y: 169, w: 152, h: 19,
          text: getBattery(), text_size: 11, char_space: 1,
          color: 0xFFC7CDD5
        });

        // Date in the window at 3 o'clock: moved exactly 2 px upward.
        const dateText = makeText({
          x: 292, y: 192, w: 57, h: 47,
          text: String(timeSensor.day || 1),
          text_size: 27,
          color: 0xFF101319
        });

        // Mechanical hands.
        hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_path: 'hour_hand.png',
          hour_centerX: 195, hour_centerY: 225,
          hour_posX: 15, hour_posY: 115,
          show_level: NORMAL
        });
        hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          minute_path: 'minute_hand.png',
          minute_centerX: 195, minute_centerY: 225,
          minute_posX: 14, minute_posY: 140,
          show_level: NORMAL
        });
        hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          second_path: 'second_hand.png',
          second_centerX: 195, second_centerY: 225,
          second_posX: 10, second_posY: 170,
          show_level: NORMAL
        });
        hmUI.createWidget(hmUI.widget.IMG, {
          x: 186, y: 216, w: 18, h: 18,
          src: 'pin.png', show_level: NORMAL
        });

        // Steps at the bottom, replacing AUTOMATIC.
        const stepsText = makeText({
          x: 105, y: 299, w: 180, h: 23,
          text: getSteps(), text_size: 12, char_space: 1,
          color: 0xFFD4D9E0
        });

        // AOD remains intentionally minimal: dim background and hour/minute hands.
        hmUI.createWidget(hmUI.widget.IMG, {
          x: 0, y: 0, w: 390, h: 450,
          src: 'background_aod.png', show_level: AOD
        });
        hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_path: 'hour_hand.png',
          hour_centerX: 195, hour_centerY: 225,
          hour_posX: 15, hour_posY: 115,
          show_level: AOD
        });
        hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          minute_path: 'minute_hand.png',
          minute_centerX: 195, minute_centerY: 225,
          minute_posX: 14, minute_posY: 140,
          show_level: AOD
        });
        hmUI.createWidget(hmUI.widget.IMG, {
          x: 186, y: 216, w: 18, h: 18,
          src: 'pin.png', show_level: AOD
        });

        // Refresh dynamic values when their sensors change.
        timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
          weekdayText.setProperty(hmUI.prop.TEXT, getWeekday());
          dateText.setProperty(hmUI.prop.TEXT, String(timeSensor.day));
        });
        batterySensor.addEventListener(hmSensor.event.CHANGE, function () {
          batteryText.setProperty(hmUI.prop.TEXT, getBattery());
        });
        stepSensor.addEventListener(hmSensor.event.CHANGE, function () {
          stepsText.setProperty(hmUI.prop.TEXT, getSteps());
        });
      },

      onInit() {
        logger.log('Blue Day-Date V2.1.1 initialized');
      },

      onDestroy() {
        logger.log('Blue Day-Date V2.1 destroyed');
      }
    });
  })();
} catch (e) {
  console.log('Blue Day-Date V2.1.1 error', e);
  if (e && e.stack) console.log(e.stack);
}
