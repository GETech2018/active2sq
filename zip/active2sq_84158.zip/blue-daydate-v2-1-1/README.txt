Blue Day-Date Style V2.1 — Amazfit Active 2 Square

This is a separate project copy. It does not overwrite the existing blue-daydate or blue-daydate-v2 folders.

Changes in V2.1:
- New silver hour, minute and second hand artwork based on the user's supplied hand designs.
- The original hand silhouettes and proportions are preserved; white/checkerboard backgrounds are removed.
- Hand pivot anchors are configured in watchface/index.js.
- Center cap reduced to 18x18 px so it does not hide the hand details.
- App name/version updated to Blue Day-Date Style V2.1 / 2.1.0 (version code 3).
- Existing POWER, STEPS, weekday and date logic is otherwise retained.

Project target: 390x450-amazfit-active-2-square
App ID: 10013

Windows setup:
1. Extract this ZIP into:
   C:\Users\Admin\Documents\ZeppProjects\
2. Confirm the folder is named blue-daydate-v2-1.
3. Open PowerShell and run:
   cd "$HOME\Documents\ZeppProjects\blue-daydate-v2-1"
   zeus.cmd build
4. If the build succeeds, run:
   zeus.cmd preview
5. Scan the QR in Zepp Developer Mode and install V2.1.

Important:
- Keep blue-daydate and blue-daydate-v2 unchanged.
- This is source code, not a prebuilt ZAB.
- Build and physical watch testing are still required.
- The current V2.1 scope changes only hand assets, their pivot coordinates, the center cap size and the displayed app version. Weekday curvature and date alignment are intentionally left for a later refinement.


V2.1.1 hand proportion revision:
- Hour hand shortened substantially and narrowed.
- Minute hand slightly shortened and narrowed.
- Second hand lengthened to be the longest.
- Pivot coordinates updated to match the new image geometry.
- Original V2.1 files are unchanged.
