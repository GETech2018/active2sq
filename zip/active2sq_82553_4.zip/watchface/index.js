﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_image_img = ''
        let normal_date_img_date_year = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 101,
              y: 368,
              src: 'bpm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 60,
              year_startY: 105,
              year_sc_array: ["num0.png","num1.png","num2.png","num3.png","num4.png","num5.png","num6.png","num7.png","num8.png","num9.png"],
              year_tc_array: ["num0.png","num1.png","num2.png","num3.png","num4.png","num5.png","num6.png","num7.png","num8.png","num9.png"],
              year_en_array: ["num0.png","num1.png","num2.png","num3.png","num4.png","num5.png","num6.png","num7.png","num8.png","num9.png"],
              year_zero: 1,
              year_space: 3,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 45,
              y: 356,
              font_array: ["num0.png","num1.png","num2.png","num3.png","num4.png","num5.png","num6.png","num7.png","num8.png","num9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 43,
              y: 311,
              font_array: ["num0.png","num1.png","num2.png","num3.png","num4.png","num5.png","num6.png","num7.png","num8.png","num9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'precent.png',
              unit_tc: 'precent.png',
              unit_en: 'precent.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 95,
              month_startY: 60,
              month_sc_array: ["num0.png","num1.png","num2.png","num3.png","num4.png","num5.png","num6.png","num7.png","num8.png","num9.png"],
              month_tc_array: ["num0.png","num1.png","num2.png","num3.png","num4.png","num5.png","num6.png","num7.png","num8.png","num9.png"],
              month_en_array: ["num0.png","num1.png","num2.png","num3.png","num4.png","num5.png","num6.png","num7.png","num8.png","num9.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 60,
              day_startY: 60,
              day_sc_array: ["num0.png","num1.png","num2.png","num3.png","num4.png","num5.png","num6.png","num7.png","num8.png","num9.png"],
              day_tc_array: ["num0.png","num1.png","num2.png","num3.png","num4.png","num5.png","num6.png","num7.png","num8.png","num9.png"],
              day_en_array: ["num0.png","num1.png","num2.png","num3.png","num4.png","num5.png","num6.png","num7.png","num8.png","num9.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 210,
              hour_startY: 60,
              hour_array: ["hour_0or.png","hour_1or.png","hour_2or.png","hour_3or.png","hour_4or.png","hour_5or.png","hour_6or.png","hour_7or.png","hour_8or.png","hour_9or.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 210,
              minute_startY: 240,
              minute_array: ["hour_0or.png","hour_1or.png","hour_2or.png","hour_3or.png","hour_4or.png","hour_5or.png","hour_6or.png","hour_7or.png","hour_8or.png","hour_9or.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });




                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}