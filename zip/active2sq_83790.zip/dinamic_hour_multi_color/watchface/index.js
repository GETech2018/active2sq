﻿try {
(() => {
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() { return __$$app$$__.app; }
    function getCurrentPage() { return __$$app$$__.current && __$$app$$__.current.module; }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
    const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')

    let debugText = null;
    function showDebug(msg) {
        try {
            if (!debugText) {
                debugText = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 10, y: 10, w: 370, h: 200,
                    text: msg,
                    color: 0xFF0000,
                    text_size: 22,
                    align_h: hmUI.align.LEFT,
                });
            } else {
                debugText.setProperty(hmUI.prop.TEXT, msg);
            }
        } catch(e) {}
    }

    const hour_bg = [
        "bg1.png","bg2.png","bg3.png","bg4.png",
        "bg5.png","bg6.png","bg7.png","bg8.png",
        "bg9.png","bg10.png","bg11.png","bg12.png"
    ];

    const hour_bg_x = [
        "bg_1_x.png","bg_2_x.png","bg_3_x.png","bg_4_x.png",
        "bg_5_x.png","bg_6_x.png","bg_7_x.png","bg_8_x.png",
        "bg_9_x.png","bg_10_x.png","bg_11_x.png","bg_12_x.png"
    ];

    let normal_analog_clock_time_pointer_hour = null;
    let normal_analog_clock_time_pointer_minute = null;
    let bgMode = 0; 
    // 0 = white, 1 = black, 2 = dark blue

    const bgColors = [0xFFFFFF, 0x000000, 0x000d25, 0x3d0000];

    let overlay_img = null;
    let current_hour_showed = -1;

    function getCurrentHour() {
        try {
            const t = hmSensor.createSensor(hmSensor.id.TIME);
            return t.hour;
        } catch(e) {
            return 0;
        }
    }

    function getImgArray() {
        return bgMode === 0 ? hour_bg : hour_bg_x;
    }

    function change_image(hour) {
        const idx = ((hour + 11) % 12);
        const arr = getImgArray();
        if (overlay_img) {
            overlay_img.setProperty(hmUI.prop.SRC, arr[idx]);
        }
    }
    function isDarkMode() {
        return bgMode !== 0; // bianco = 0, nero e blu = dark
    }
    function setBackgroundColor() {
        try {
            hmUI.updateStatusBarStyle?.({
                background: bgColors[bgMode]
            });
        } catch(e) {}

        // fallback: full screen rect
        if (!__bg_rect__) return;

        __bg_rect__.setProperty(hmUI.prop.COLOR, bgColors[bgMode]);
    }

    function change_hands() {
    if (normal_analog_clock_time_pointer_hour) hmUI.deleteWidget(normal_analog_clock_time_pointer_hour);
    if (normal_analog_clock_time_pointer_minute) hmUI.deleteWidget(normal_analog_clock_time_pointer_minute);

    const dark = isDarkMode();

    normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
        hour_path: dark ? '0004.png' : '0069S.png',
        hour_centerX: 195, hour_centerY: 225,
        hour_posX: 195, hour_posY: 225,
    });

    normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
        minute_path: dark ? '0003.png' : '0070S.png',
        minute_centerX: 195, minute_centerY: 225,
        minute_posX: 195, minute_posY: 225,
    });

}

    let __bg_rect__ = null;

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
        init_view() {

            current_hour_showed = getCurrentHour();

            // BACKGROUND COLOR (nuovo)
            __bg_rect__ = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                x: 0, y: 0, w: 390, h: 450,
                color: bgColors[bgMode]
            });

            // OVERLAY IMAGE (ex background ora diventa layer sopra)
            overlay_img = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0, y: 0, w: 390, h: 450,
                src: getImgArray()[(current_hour_showed + 11) % 12],
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // BUTTON CAMBIO TEMA
            hmUI.createWidget(hmUI.widget.BUTTON, {
                x: 145, y: 340,
                w: 100, h: 50,
                radius: 25,
                normal_src: 'transparent.png',
                press_src: 'red.png',
                click_func: () => {
                    bgMode = (bgMode + 1) % 4;

                    setBackgroundColor();
                    change_image(current_hour_showed);
                    change_hands();
                }
            });

            // LANCETTE
            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                hour_path: '0069S.png',
                hour_centerX: 195, hour_centerY: 225,
                hour_posX: 195, hour_posY: 225,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                minute_path: '0070S.png',
                minute_centerX: 195, minute_centerY: 225,
                minute_posX: 195, minute_posY: 225,
            });

            hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                second_path: '0005.png',
                second_centerX: 195, second_centerY: 225,
                second_posX: 12, second_posY: 180,
            });
            change_hands();
        },

        build() {
            this.init_view();

            hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: () => {
                    const hr = getCurrentHour();
                    if (hr !== current_hour_showed) {
                        current_hour_showed = hr;
                        change_image(hr); // SOLO immagine, NON background
                    }
                }
            });
        },

        onInit() {
            logger.log('init');
        },

        onShow() {
            logger.log('show');
        },

        onDestroy() {
            logger.log('destroy');
        }
    });

})();
} catch (e) {
    hmUI.createWidget(hmUI.widget.TEXT, {
        x: 10, y: 10, w: 370, h: 300,
        text: 'CRASH:\n' + e,
        color: 0xFF0000,
        text_size: 22,
    });
    console.log(e);
}