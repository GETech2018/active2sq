﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

// for vibration feedback
const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
let timer_StopVibrate = null;

function makeVibrate(level = 1) {
  let stopDelay = 50;
  stopVibrate();
  
  // after oct 23 system update the values are as follow: 1 (scene 26 - low) for buttons,
  // 2 (scene 27 - mid) for open settings and 3 (scene 29 - high) for closing settings.
  const levelToScene = {
    1: 26,
    2: 27,
    3: 29
  };

  let scene = levelToScene[level] || 25;
  vibrate.scene = scene;
  if (scene > 25) stopDelay = 1300;
  vibrate.start();
  timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibrate, {});
}

function stopVibrate() {
  vibrate.stop();
  if (timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
}
        // end user_functions.js

        let normal_background_bg_img = ''
        let idle_background_bg_img = ''
        let idle_image_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
const colorsSet = [
    "WHITE", "BLUE", "CYAN", "TURQUOISE", "GREEN", "LIME", "YELLOW", "ORANGE", "RED", "PINK", "VIOLET"
];

let colorIndex = 0;
let currFolderColor = "sets/" + colorsSet[colorIndex] + "/";
let currBgColor = "bg_colors/" + colorsSet[colorIndex] + ".png";

let bgColorWatchface = hmUI.createWidget(hmUI.widget.IMG, { //background color
    x: 0,
    y: 0,
    w: 390,
    h: 450,
    src: currBgColor,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let bgWatchface = hmUI.createWidget(hmUI.widget.IMG, { //background
    x: 0,
    y: 0,
    w: 390,
    h: 450,
    src: 'BG.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let weatherIcon = hmUI.createWidget(hmUI.widget.IMG_LEVEL, { // weather icon 
    x: 155,
    y: 352,
    image_array: ["weather/WEATHERICON_1.png","weather/WEATHERICON_2.png","weather/WEATHERICON_3.png","weather/WEATHERICON_4.png","weather/WEATHERICON_5.png","weather/WEATHERICON_6.png","weather/WEATHERICON_7.png","weather/WEATHERICON_8.png","weather/WEATHERICON_9.png","weather/WEATHERICON_10.png","weather/WEATHERICON_11.png","weather/WEATHERICON_12.png","weather/WEATHERICON_13.png","weather/WEATHERICON_14.png","weather/WEATHERICON_15.png","weather/WEATHERICON_16.png","weather/WEATHERICON_17.png","weather/WEATHERICON_18.png","weather/WEATHERICON_19.png","weather/WEATHERICON_20.png","weather/WEATHERICON_21.png","weather/WEATHERICON_22.png","weather/WEATHERICON_23.png","weather/WEATHERICON_24.png","weather/WEATHERICON_25.png","weather/WEATHERICON_26.png","weather/WEATHERICON_27.png","weather/WEATHERICON_28.png","weather/WEATHERICON_29.png"],
    image_length: 29,
    type: hmUI.data_type.WEATHER_CURRENT,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let weatherTemp = hmUI.createWidget(hmUI.widget.TEXT_IMG, { // weather temp
    x: 221,
    y: 359,
    font_array: [currFolderColor+"DATA_0.png",currFolderColor+"DATA_1.png",currFolderColor+"DATA_2.png",currFolderColor+"DATA_3.png",currFolderColor+"DATA_4.png",currFolderColor+"DATA_5.png",currFolderColor+"DATA_6.png",currFolderColor+"DATA_7.png",currFolderColor+"DATA_8.png",currFolderColor+"DATA_9.png"],
    padding: false,
    h_space: 0,
    unit_sc: currFolderColor+'DEGREE.png',
    unit_tc: currFolderColor+'DEGREE.png',
    unit_en: currFolderColor+'DEGREE.png',
    imperial_unit_sc: currFolderColor+'DEGREE.png',
    imperial_unit_tc: currFolderColor+'DEGREE.png',
    imperial_unit_en: currFolderColor+'DEGREE.png',
    negative_image: currFolderColor+'DATA_NEGATIVE.png',
    invalid_image: currFolderColor+'DATA_NODATA.png',
    align_h: hmUI.align.LEFT,
    type: hmUI.data_type.WEATHER_CURRENT,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

const temperatureUnit = hmSetting.getTemperatureUnit();

let hrmDigits = hmUI.createWidget(hmUI.widget.TEXT_IMG, { //hrm
    x: 31,
    y: 359,
    font_array: [currFolderColor+"DATA_0.png",currFolderColor+"DATA_1.png",currFolderColor+"DATA_2.png",currFolderColor+"DATA_3.png",currFolderColor+"DATA_4.png",currFolderColor+"DATA_5.png",currFolderColor+"DATA_6.png",currFolderColor+"DATA_7.png",currFolderColor+"DATA_8.png",currFolderColor+"DATA_9.png"],
    padding: false,
    h_space: 0,
    align_h: hmUI.align.LEFT,
    type: hmUI.data_type.HEART,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let stepsDigits = hmUI.createWidget(hmUI.widget.TEXT_IMG, { //steps
    x: 184,
    y: 266,
    font_array: [currFolderColor+"DATA_0.png",currFolderColor+"DATA_1.png",currFolderColor+"DATA_2.png",currFolderColor+"DATA_3.png",currFolderColor+"DATA_4.png",currFolderColor+"DATA_5.png",currFolderColor+"DATA_6.png",currFolderColor+"DATA_7.png",currFolderColor+"DATA_8.png",currFolderColor+"DATA_9.png"],
    padding: false,
    h_space: 0,
    align_h: hmUI.align.RIGHT,
    type: hmUI.data_type.STEP,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let batteryGraphPlaceholder = hmUI.createWidget(hmUI.widget.IMG, { //battery graph placeholder
    x: 29,
    y: 82,
    w: 390,
    h: 450,
    src: "GRAPH_DEFAULT.png",
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let batteryGraph = hmUI.createWidget(hmUI.widget.IMG_LEVEL, { //battery graph
    x: 29,
    y: 82,
    image_array: [currFolderColor+"GRAPHS_20.png",currFolderColor+"GRAPHS_40.png",currFolderColor+"GRAPHS_60.png",currFolderColor+"GRAPHS_80.png",currFolderColor+"GRAPHS_100.png"],
    image_length: 5,
    type: hmUI.data_type.BATTERY,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let caloriesGraph = hmUI.createWidget(hmUI.widget.IMG_LEVEL, { //calories graph
    x: 29,
    y: 174,
    image_array: [currFolderColor+"GRAPHS_20.png",currFolderColor+"GRAPHS_40.png",currFolderColor+"GRAPHS_60.png",currFolderColor+"GRAPHS_80.png",currFolderColor+"GRAPHS_100.png"],
    image_length: 5,
    type: hmUI.data_type.CAL,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let stepsGraph = hmUI.createWidget(hmUI.widget.IMG_LEVEL, { //steps graph
    x: 29,
    y: 265,
    image_array: [currFolderColor+"GRAPHS_20.png",currFolderColor+"GRAPHS_40.png",currFolderColor+"GRAPHS_60.png",currFolderColor+"GRAPHS_80.png",currFolderColor+"GRAPHS_100.png"],
    image_length: 5,
    type: hmUI.data_type.STEP,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let dayNumber = hmUI.createWidget(hmUI.widget.IMG_DATE, { //day number
    day_startX: 289,
    day_startY: 173,
    day_sc_array: ["DATA_0.png","DATA_1.png","DATA_2.png","DATA_3.png","DATA_4.png","DATA_5.png","DATA_6.png","DATA_7.png","DATA_8.png","DATA_9.png"],
    day_tc_array: ["DATA_0.png","DATA_1.png","DATA_2.png","DATA_3.png","DATA_4.png","DATA_5.png","DATA_6.png","DATA_7.png","DATA_8.png","DATA_9.png"],
    day_en_array: ["DATA_0.png","DATA_1.png","DATA_2.png","DATA_3.png","DATA_4.png","DATA_5.png","DATA_6.png","DATA_7.png","DATA_8.png","DATA_9.png"],
    day_zero: 1,
    day_space: 0,
    day_align: hmUI.align.LEFT,
    day_is_character: false,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let dayOfWeek = hmUI.createWidget(hmUI.widget.IMG_WEEK, { //day of the week
    x: 149,
    y: 173,
    week_en: ["DAYS_EN_01.png","DAYS_EN_02.png","DAYS_EN_03.png","DAYS_EN_04.png","DAYS_EN_05.png","DAYS_EN_06.png","DAYS_EN_07.png"],
    week_tc: ["DAYS_EN_01.png","DAYS_EN_02.png","DAYS_EN_03.png","DAYS_EN_04.png","DAYS_EN_05.png","DAYS_EN_06.png","DAYS_EN_07.png"],
    week_sc: ["DAYS_EN_01.png","DAYS_EN_02.png","DAYS_EN_03.png","DAYS_EN_04.png","DAYS_EN_05.png","DAYS_EN_06.png","DAYS_EN_07.png"],
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let clockSeparator = hmUI.createWidget(hmUI.widget.IMG_ANIM, { //hr separator animation
    x: 248,
    y: 77,
    anim_path: "animation",
    anim_ext: "png",
    anim_prefix: "CLOCK_SEPARATOR",
    anim_fps: 2,
    anim_size: 2,
    repeat_count: 0,
    anim_repeat: true,
    anim_status:hmUI.anim_status.START,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let clockHrMin = hmUI.createWidget(hmUI.widget.IMG_TIME, { // clock
    hour_startX: 148,
    hour_startY: 61,
    hour_array: ["CLOCK_0.png","CLOCK_1.png","CLOCK_2.png","CLOCK_3.png","CLOCK_4.png","CLOCK_5.png","CLOCK_6.png","CLOCK_7.png","CLOCK_8.png","CLOCK_9.png"],
    hour_zero: 1,
    hour_space: 0,
    hour_angle: 0,
    hour_align: hmUI.align.LEFT,

    minute_startX: 262,
    minute_startY: 61,
    minute_array: ["CLOCK_0.png","CLOCK_1.png","CLOCK_2.png","CLOCK_3.png","CLOCK_4.png","CLOCK_5.png","CLOCK_6.png","CLOCK_7.png","CLOCK_8.png","CLOCK_9.png"],
    minute_zero: 1,
    minute_space: 0,
    minute_angle: 0,
    minute_follow: 0,
    minute_align: hmUI.align.LEFT,

    show_level: hmUI.show_level.ONLY_NORMAL,
});
            // end user_script.js


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'BG_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'BG_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 149,
              y: 173,
              week_en: ["DAYS_EN_01.png","DAYS_EN_02.png","DAYS_EN_03.png","DAYS_EN_04.png","DAYS_EN_05.png","DAYS_EN_06.png","DAYS_EN_07.png"],
              week_tc: ["DAYS_EN_01.png","DAYS_EN_02.png","DAYS_EN_03.png","DAYS_EN_04.png","DAYS_EN_05.png","DAYS_EN_06.png","DAYS_EN_07.png"],
              week_sc: ["DAYS_EN_01.png","DAYS_EN_02.png","DAYS_EN_03.png","DAYS_EN_04.png","DAYS_EN_05.png","DAYS_EN_06.png","DAYS_EN_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 289,
              day_startY: 173,
              day_sc_array: ["DATA_0.png","DATA_1.png","DATA_2.png","DATA_3.png","DATA_4.png","DATA_5.png","DATA_6.png","DATA_7.png","DATA_8.png","DATA_9.png"],
              day_tc_array: ["DATA_0.png","DATA_1.png","DATA_2.png","DATA_3.png","DATA_4.png","DATA_5.png","DATA_6.png","DATA_7.png","DATA_8.png","DATA_9.png"],
              day_en_array: ["DATA_0.png","DATA_1.png","DATA_2.png","DATA_3.png","DATA_4.png","DATA_5.png","DATA_6.png","DATA_7.png","DATA_8.png","DATA_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 148,
              hour_startY: 61,
              hour_array: ["CLOCK_0.png","CLOCK_1.png","CLOCK_2.png","CLOCK_3.png","CLOCK_4.png","CLOCK_5.png","CLOCK_6.png","CLOCK_7.png","CLOCK_8.png","CLOCK_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 262,
              minute_startY: 61,
              minute_array: ["CLOCK_0.png","CLOCK_1.png","CLOCK_2.png","CLOCK_3.png","CLOCK_4.png","CLOCK_5.png","CLOCK_6.png","CLOCK_7.png","CLOCK_8.png","CLOCK_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 27,
              y: 265,
              w: 340,
              h: 60,
              src: 'BTN_BIG.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 27,
              y: 175,
              w: 100,
              h: 60,
              src: 'BTN_BIG.png',
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 27,
              y: 355,
              w: 100,
              h: 60,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 27,
              y: 75,
              w: 100,
              h: 60,
              src: 'BTN_BIG.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 140,
              y: 65,
              w: 230,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BTN_BIG.png',
              normal_src: 'BTN_BIG.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 140,
              y: 350,
              w: 230,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BTN_BIG.png',
              normal_src: 'BTN_BIG.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 140,
              y: 165,
              w: 230,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BTN_BIG.png',
              normal_src: 'BTN_BIG.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 0,
              w: 128,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BTN_BIG.png',
              normal_src: 'BTN_BIG.png',
              click_func: (button_widget) => {
                showSettings()
makeVibrate(2)
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

//settings layout
let settingsBG = hmUI.createWidget(hmUI.widget.IMG, {
    x: 0,
    y: 0,
    src: "settings/SETTINGS_BG.png",
});

let prevColorbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 24,
    y: -8,
    w: 90,
    h: 90,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTN_SELECTOR_UP_PRESSED.png',
    normal_src: 'settings/BTN_SELECTOR_UP_NORMAL.png',
    click_func: (button_widget) => {
    prevColor()
    makeVibrate(1)
    }, // end func
}); // end button

let nextColorbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 24,
    y: 132,
    w: 90,
    h: 90,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTN_SELECTOR_DOWN_PRESSED.png',
    normal_src: 'settings/BTN_SELECTOR_DOWN_NORMAL.png',
    click_func: (button_widget) => {
    nextColor()
    makeVibrate(1)
    }, // end func
}); // end button

let Confirmbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 23,
    y: 223,
    w: 120,
    h: 90,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTN_CONFIRM_PRESSED.png',
    normal_src: 'settings/BTN_CONFIRM_NORMAL.png',
    click_func: (button_widget) => {
    hideSettings()
    makeVibrate(3)
    }, // end func
}); // end button

// functions to change colors
function prevColor(){
    colorIndex = (colorIndex - 1 + colorsSet.length) % colorsSet.length;
    updateWatchface();
}

function nextColor(){
    colorIndex = (colorIndex + 1) % colorsSet.length;
    updateWatchface();
}

//function to update the whole watchface with the selected color
function updateWatchface(){
    currFolderColor = "sets/" + colorsSet[colorIndex] + "/";
    currBgColor = "bg_colors/" + colorsSet[colorIndex] + ".png";

    bgColorWatchface.setProperty(hmUI.prop.MORE, { //bgcolor
        x: 0,
        y: 0,
        w: 390,
        h: 450,
        src: currBgColor,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    weatherTemp.setProperty(hmUI.prop.MORE, { //weather temp
        x: 221,
        y: 359,
        font_array: [currFolderColor+"DATA_0.png",currFolderColor+"DATA_1.png",currFolderColor+"DATA_2.png",currFolderColor+"DATA_3.png",currFolderColor+"DATA_4.png",currFolderColor+"DATA_5.png",currFolderColor+"DATA_6.png",currFolderColor+"DATA_7.png",currFolderColor+"DATA_8.png",currFolderColor+"DATA_9.png"],
        padding: false,
        h_space: 0,
        unit_sc: currFolderColor+'DEGREE.png',
        unit_tc: currFolderColor+'DEGREE.png',
        unit_en: currFolderColor+'DEGREE.png',
        imperial_unit_sc: currFolderColor+'DEGREE.png',
        imperial_unit_tc: currFolderColor+'DEGREE.png',
        imperial_unit_en: currFolderColor+'DEGREE.png',
        negative_image: currFolderColor+'DATA_NEGATIVE.png',
        invalid_image: currFolderColor+'DATA_NODATA.png',
        align_h: hmUI.align.LEFT,
        type: hmUI.data_type.WEATHER_CURRENT,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    hrmDigits.setProperty(hmUI.prop.MORE, { //hrm
        x: 31,
        y: 359,
        font_array: [currFolderColor+"DATA_0.png",currFolderColor+"DATA_1.png",currFolderColor+"DATA_2.png",currFolderColor+"DATA_3.png",currFolderColor+"DATA_4.png",currFolderColor+"DATA_5.png",currFolderColor+"DATA_6.png",currFolderColor+"DATA_7.png",currFolderColor+"DATA_8.png",currFolderColor+"DATA_9.png"],
        padding: false,
        h_space: 0,
        align_h: hmUI.align.LEFT,
        type: hmUI.data_type.HEART,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    stepsDigits.setProperty(hmUI.prop.MORE, { //steps
        x: 184,
        y: 266,
        font_array: [currFolderColor+"DATA_0.png",currFolderColor+"DATA_1.png",currFolderColor+"DATA_2.png",currFolderColor+"DATA_3.png",currFolderColor+"DATA_4.png",currFolderColor+"DATA_5.png",currFolderColor+"DATA_6.png",currFolderColor+"DATA_7.png",currFolderColor+"DATA_8.png",currFolderColor+"DATA_9.png"],
        padding: false,
        h_space: 0,
        align_h: hmUI.align.RIGHT,
        type: hmUI.data_type.STEP,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    batteryGraph.setProperty(hmUI.prop.MORE, { //battery graph
        x: 29,
        y: 82,
        image_array: [currFolderColor+"GRAPHS_20.png",currFolderColor+"GRAPHS_40.png",currFolderColor+"GRAPHS_60.png",currFolderColor+"GRAPHS_80.png",currFolderColor+"GRAPHS_100.png"],
        image_length: 5,
        type: hmUI.data_type.BATTERY,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    caloriesGraph.setProperty(hmUI.prop.MORE, { //calories graph
        x: 29,
        y: 174,
        image_array: [currFolderColor+"GRAPHS_20.png",currFolderColor+"GRAPHS_40.png",currFolderColor+"GRAPHS_60.png",currFolderColor+"GRAPHS_80.png",currFolderColor+"GRAPHS_100.png"],
        image_length: 5,
        type: hmUI.data_type.CAL,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    stepsGraph.setProperty(hmUI.prop.MORE, { //steps graph
        x: 29,
        y: 265,
        image_array: [currFolderColor+"GRAPHS_20.png",currFolderColor+"GRAPHS_40.png",currFolderColor+"GRAPHS_60.png",currFolderColor+"GRAPHS_80.png",currFolderColor+"GRAPHS_100.png"],
        image_length: 5,
        type: hmUI.data_type.STEP,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    hmFS.SysProSetInt('colorIndexAOD', colorIndex);
}

function hideSettings(){
    // normal buttons
    Button_1.setProperty(hmUI.prop.VISIBLE, true);
    Button_2.setProperty(hmUI.prop.VISIBLE, true);
    Button_3.setProperty(hmUI.prop.VISIBLE, true);

    //batterygraph to see the color through
    batteryGraphPlaceholder.setProperty(hmUI.prop.VISIBLE, true);
    batteryGraph.setProperty(hmUI.prop.VISIBLE, true);
    
    // settings layout
    settingsBG.setProperty(hmUI.prop.VISIBLE, false);
    prevColorbtn.setProperty(hmUI.prop.VISIBLE, false);
    nextColorbtn.setProperty(hmUI.prop.VISIBLE, false);
    Confirmbtn.setProperty(hmUI.prop.VISIBLE, false);
}
hideSettings();

function showSettings(){
    // normal buttons
    Button_1.setProperty(hmUI.prop.VISIBLE, false);
    Button_2.setProperty(hmUI.prop.VISIBLE, false);
    Button_3.setProperty(hmUI.prop.VISIBLE, false);

    //batterygraph to see the color through
    batteryGraphPlaceholder.setProperty(hmUI.prop.VISIBLE, false);
    batteryGraph.setProperty(hmUI.prop.VISIBLE, false);
    
    // settings layout
    settingsBG.setProperty(hmUI.prop.VISIBLE, true);
    prevColorbtn.setProperty(hmUI.prop.VISIBLE, true);
    nextColorbtn.setProperty(hmUI.prop.VISIBLE, true);
    Confirmbtn.setProperty(hmUI.prop.VISIBLE, true);
}

idle_background_bg_img.setProperty(hmUI.prop.SRC, "bg_colors/" + colorsSet[hmFS.SysProGetInt('colorIndexAOD') ?? 0] + ".png");
            // end user_script_end.js

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');

                console.log('resume_call.js');
                // start resume_call.js

clockSeparator.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');

                console.log('pause_call.js');
                // start pause_call.js

clockSeparator.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
hideSettings();
                // end pause_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}