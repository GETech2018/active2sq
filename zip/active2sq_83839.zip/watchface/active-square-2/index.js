// Custom Watch Face for Amazfit Active Square 2
// Screen: 390x450

const SCREEN_WIDTH = 390;
const SCREEN_HEIGHT = 450;

// Global API sensors
const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
const batteryInfo = hmSensor.createSensor(hmSensor.id.BATTERY);
const stepInfo = hmSensor.createSensor(hmSensor.id.STEP);
const heartInfo = hmSensor.createSensor(hmSensor.id.HEART);
const weatherInfo = hmSensor.createSensor(hmSensor.id.WEATHER);

WatchFace({
  onInit() {
    console.log('Watch Face Init');
  },

  build() {
    console.log('Watch Face Build');
    
    // Background
    hmUI.createWidget(hmUI.widget.FILL_RECT, {
      x: 0,
      y: 0,
      w: SCREEN_WIDTH,
      h: SCREEN_HEIGHT,
      color: 0x000000
    });
    
    // Date text - top left
    const dateWidget = hmUI.createWidget(hmUI.widget.TEXT, {
      x: 30,
      y: 60,
      w: 250,
      h: 40,
      text: 'SAT | SEP 20',
      text_size: 28,
      color: 0xFFFFFF,
      align_h: hmUI.align.LEFT,
      align_v: hmUI.align.CENTER_V
    });
    
    // Battery percentage - top right
    const batteryWidget = hmUI.createWidget(hmUI.widget.TEXT, {
      x: SCREEN_WIDTH - 120,
      y: 60,
      w: 100,
      h: 40,
      text: '🔋 82%',
      text_size: 28,
      color: 0xFFFFFF,
      align_h: hmUI.align.RIGHT,
      align_v: hmUI.align.CENTER_V
    });
    
    // Large time display - center
    const timeWidget = hmUI.createWidget(hmUI.widget.TEXT, {
      x: 0,
      y: 150,
      w: SCREEN_WIDTH,
      h: 180,
      text: '10:24',
      text_size: 120,
      color: 0xFFFFFF,
      align_h: hmUI.align.CENTER_H,
      align_v: hmUI.align.CENTER_V
    });
    
    // Time touch area - tap for stopwatch, long press for alarm
    const timeButton = hmUI.createWidget(hmUI.widget.IMG, {
      x: 0,
      y: 150,
      w: SCREEN_WIDTH,
      h: 180,
      src: ''
    });
    
    let longPressTimer = null;
    
    timeButton.addEventListener(hmUI.event.CLICK_DOWN, function() {
      if (longPressTimer === null) {
        longPressTimer = setTimeout(function() {
          // Long press - open alarms
          hmApp.gotoPage({ url: 'AlarmPage' });
          longPressTimer = null;
        }, 800);
      }
    });
    
    timeButton.addEventListener(hmUI.event.CLICK_UP, function() {
      if (longPressTimer !== null) {
        clearTimeout(longPressTimer);
        longPressTimer = null;
        // Short tap - open stopwatch
        hmApp.gotoPage({ url: 'StopwatchPage' });
      }
    });
    
    // Steps section
    const stepsIcon = hmUI.createWidget(hmUI.widget.TEXT, {
      x: 35,
      y: 350,
      w: 80,
      h: 60,
      text: '👣',
      text_size: 50,
      color: 0x4ADE80,
      align_h: hmUI.align.CENTER_H,
      align_v: hmUI.align.CENTER_V
    });
    
    const stepsValue = hmUI.createWidget(hmUI.widget.TEXT, {
      x: 20,
      y: 410,
      w: 110,
      h: 50,
      text: '8,432',
      text_size: 40,
      color: 0xFFFFFF,
      align_h: hmUI.align.CENTER_H,
      align_v: hmUI.align.CENTER_V
    });
    
    const stepsButton = hmUI.createWidget(hmUI.widget.IMG, {
      x: 20,
      y: 350,
      w: 110,
      h: 110,
      src: ''
    });
    
    stepsButton.addEventListener(hmUI.event.CLICK_DOWN, function() {
      hmApp.gotoPage({ url: 'StepPage' });
    });
    
    // Heart rate section
    const heartIcon = hmUI.createWidget(hmUI.widget.TEXT, {
      x: SCREEN_WIDTH / 2 - 40,
      y: 350,
      w: 80,
      h: 60,
      text: '❤️',
      text_size: 50,
      color: 0xFB7185,
      align_h: hmUI.align.CENTER_H,
      align_v: hmUI.align.CENTER_V
    });
    
    const heartValue = hmUI.createWidget(hmUI.widget.TEXT, {
      x: SCREEN_WIDTH / 2 - 55,
      y: 410,
      w: 110,
      h: 50,
      text: '72',
      text_size: 40,
      color: 0xFFFFFF,
      align_h: hmUI.align.CENTER_H,
      align_v: hmUI.align.CENTER_V
    });
    
    const heartLabel = hmUI.createWidget(hmUI.widget.TEXT, {
      x: SCREEN_WIDTH / 2 - 55,
      y: 448,
      w: 110,
      h: 30,
      text: 'bpm',
      text_size: 24,
      color: 0x999999,
      align_h: hmUI.align.CENTER_H,
      align_v: hmUI.align.CENTER_V
    });
    
    const heartButton = hmUI.createWidget(hmUI.widget.IMG, {
      x: SCREEN_WIDTH / 2 - 55,
      y: 350,
      w: 110,
      h: 130,
      src: ''
    });
    
    heartButton.addEventListener(hmUI.event.CLICK_DOWN, function() {
      hmApp.gotoPage({ url: 'HeartRatePage' });
    });
    
    // Temperature section (replacing calories)
    const tempIcon = hmUI.createWidget(hmUI.widget.TEXT, {
      x: SCREEN_WIDTH - 115,
      y: 350,
      w: 80,
      h: 60,
      text: '🌡️',
      text_size: 50,
      color: 0xFBBF24,
      align_h: hmUI.align.CENTER_H,
      align_v: hmUI.align.CENTER_V
    });
    
    const tempValue = hmUI.createWidget(hmUI.widget.TEXT, {
      x: SCREEN_WIDTH - 130,
      y: 410,
      w: 110,
      h: 50,
      text: '22',
      text_size: 40,
      color: 0xFFFFFF,
      align_h: hmUI.align.CENTER_H,
      align_v: hmUI.align.CENTER_V
    });
    
    const tempLabel = hmUI.createWidget(hmUI.widget.TEXT, {
      x: SCREEN_WIDTH - 130,
      y: 448,
      w: 110,
      h: 30,
      text: '°C',
      text_size: 24,
      color: 0x999999,
      align_h: hmUI.align.CENTER_H,
      align_v: hmUI.align.CENTER_V
    });
    
    const tempButton = hmUI.createWidget(hmUI.widget.IMG, {
      x: SCREEN_WIDTH - 130,
      y: 350,
      w: 110,
      h: 130,
      src: ''
    });
    
    tempButton.addEventListener(hmUI.event.CLICK_DOWN, function() {
      hmApp.gotoPage({ url: 'WeatherPage' });
    });
    
    // Update function
    function updateWatchFace() {
      try {
        // Update time
        const hour = timeSensor.hour;
        const minute = timeSensor.minute;
        const timeStr = (hour < 10 ? '0' : '') + hour + ':' + (minute < 10 ? '0' : '') + minute;
        timeWidget.setProperty(hmUI.prop.MORE, { text: timeStr });
        
        // Update date
        const days = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
        const months = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
        const dayOfWeek = timeSensor.week;
        const day = timeSensor.day;
        const month = timeSensor.month;
        const dateStr = days[dayOfWeek] + ' | ' + months[month - 1] + ' ' + day;
        dateWidget.setProperty(hmUI.prop.MORE, { text: dateStr });
        
        // Update battery
        const battery = batteryInfo.current;
        batteryWidget.setProperty(hmUI.prop.MORE, { text: '🔋 ' + battery + '%' });
        
        // Update steps
        const steps = stepInfo.current;
        const stepsStr = steps.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        stepsValue.setProperty(hmUI.prop.MORE, { text: stepsStr });
        
        // Update heart rate
        const heartRate = heartInfo.current;
        if (heartRate > 0) {
          heartValue.setProperty(hmUI.prop.MORE, { text: heartRate.toString() });
        }
        
        // Update temperature
        if (weatherInfo.current) {
          const temp = weatherInfo.current.temperature;
          if (temp !== undefined) {
            tempValue.setProperty(hmUI.prop.MORE, { text: Math.round(temp).toString() });
          }
        }
      } catch (e) {
        console.log('Update error: ' + e);
      }
    }
    
    // Initial update
    updateWatchFace();
    
    // Update every second
    const updateTimer = timer.createTimer(1000, 1000, function() {
      updateWatchFace();
    });
  },

  onDestroy() {
    console.log('Watch Face Destroy');
  }
});
